function Players() {
  return <div></div>;
}

export default Players;
