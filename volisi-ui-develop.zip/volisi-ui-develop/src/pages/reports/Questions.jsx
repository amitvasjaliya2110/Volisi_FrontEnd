function Questions() {
  return <div></div>;
}

export default Questions;
