import { createContext } from 'react';

const volisiContext = createContext("");

export default volisiContext;